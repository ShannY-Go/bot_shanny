"""Чистые функции без discord: шаблоны, пинги, цвета, форматирование."""
import re
from datetime import datetime, timezone


class _SafeDict(dict):
    """Если в шаблоне есть неизвестная переменная — оставляем её как есть."""

    def __missing__(self, key):
        return "{" + key + "}"


def render(template: str | None, **values) -> str:
    """Подставляет {переменные} в шаблон из конфига. Не падает на кривых скобках."""
    if not template:
        return ""
    try:
        return template.format_map(_SafeDict(values)).strip()
    except (ValueError, IndexError, AttributeError):
        return template.strip()


def is_set(value) -> bool:
    """ID в конфиге задан (не 0 и не пустой)."""
    try:
        return int(value) > 0
    except (TypeError, ValueError):
        return False


def ping_text(value) -> str:
    """
    Превращает настройку пинга в текст:
      0 / "" -> без пинга
      "everyone" -> @everyone, "here" -> @here
      123456789 -> <@&123456789> (роль)
    """
    if value is None or value == "" or value == 0:
        return ""
    if isinstance(value, str):
        v = value.strip().lower().lstrip("@")
        if v == "everyone":
            return "@everyone"
        if v == "here":
            return "@here"
        if not v.isdigit():
            return ""
        value = int(v)
    try:
        value = int(value)
    except (TypeError, ValueError):
        return ""
    return f"<@&{value}>" if value > 0 else ""


def parse_color(value, default: int = 0x9B59B6) -> int:
    """'#ff0000' / 'ff0000' / 0xff0000 -> int."""
    if value is None or value == "":
        return default
    if isinstance(value, int):
        return value
    v = str(value).strip().lstrip("#")
    if v.lower().startswith("0x"):
        v = v[2:]
    try:
        return int(v, 16)
    except ValueError:
        return default


def fmt_number(n) -> str:
    """12345 -> '12 345'"""
    try:
        return f"{int(n):,}".replace(",", " ")
    except (TypeError, ValueError):
        return str(n)


def fmt_duration(seconds: float) -> str:
    seconds = max(0, int(seconds))
    h, rem = divmod(seconds, 3600)
    m = rem // 60
    if h and m:
        return f"{h} ч {m} мин"
    if h:
        return f"{h} ч"
    return f"{max(m, 1)} мин"


def parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt


_MSG_LINK = re.compile(r"discord(?:app)?\.com/channels/(\d+|@me)/(\d+)/(\d+)")


def parse_message_link(link: str) -> tuple[int, int] | None:
    """Ссылка на сообщение -> (channel_id, message_id)."""
    m = _MSG_LINK.search(link or "")
    if not m:
        return None
    return int(m.group(2)), int(m.group(3))


WEBHOOK_URL_RE = re.compile(
    r"^https://(?:(?:ptb|canary)\.)?discord(?:app)?\.com/api(?:/v\d+)?/webhooks/\d+/[\w-]+/?$"
)


def is_webhook_url(url: str) -> bool:
    return bool(WEBHOOK_URL_RE.match((url or "").strip()))


_MD_SPECIAL = re.compile(r"([\\*_~`|\[\]])")


def md_escape(text: str | None) -> str:
    """Экранирует markdown-символы, чтобы название видео не ломало разметку сообщения."""
    return _MD_SPECIAL.sub(r"\\\1", text or "")


def shorten(text: str | None, limit: int) -> str:
    text = (text or "").strip()
    if len(text) <= limit:
        return text
    return text[: limit - 1].rstrip() + "…"

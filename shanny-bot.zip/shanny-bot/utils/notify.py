"""
Отправка уведомлений: либо от имени бота, либо через вебхук
(тогда сообщение выглядит как от "ShannY" с твоей аватаркой).
"""
import logging
from dataclasses import dataclass

import discord
from discord.utils import MISSING

from .helpers import ALLOW_PINGS

log = logging.getLogger("notify")


@dataclass
class SentRef:
    channel_id: int
    message_id: int
    via_webhook: bool
    jump_url: str = ""


class Notifier:
    def __init__(self, bot):
        self.bot = bot
        self._hooks: dict[int, discord.Webhook] = {}

    @property
    def cfg(self) -> dict:
        return self.bot.cfg.get("notify", {})

    async def get_channel(self, channel_id: int):
        channel = self.bot.get_channel(channel_id)
        if channel is None:
            channel = await self.bot.fetch_channel(channel_id)
        return channel

    async def get_webhook(self, channel, name: str | None = None) -> discord.Webhook:
        """Берёт вебхук бота в канале или создаёт новый. Кэширует."""
        cached = self._hooks.get(channel.id)
        if cached is not None:
            return cached
        if not hasattr(channel, "webhooks"):
            raise RuntimeError(f"В канале #{getattr(channel, 'name', channel.id)} нельзя создать вебхук")
        for hook in await channel.webhooks():
            if hook.token and hook.user and self.bot.user and hook.user.id == self.bot.user.id:
                self._hooks[channel.id] = hook
                return hook
        hook = await channel.create_webhook(
            name=(name or self.cfg.get("webhook_name") or "ShannY")[:80],
            reason="Вебхук для уведомлений бота",
        )
        self._hooks[channel.id] = hook
        return hook

    def forget_webhook(self, channel_id: int) -> None:
        self._hooks.pop(channel_id, None)

    async def send(
        self,
        channel_id: int,
        *,
        content: str | None = None,
        embed: discord.Embed | None = None,
        view: discord.ui.View | None = None,
        use_webhook: bool | None = None,
        username: str | None = None,
        avatar_url: str | None = None,
    ) -> SentRef:
        channel = await self.get_channel(int(channel_id))
        if use_webhook is None:
            use_webhook = bool(self.cfg.get("use_webhook", False))

        kwargs = {"allowed_mentions": ALLOW_PINGS}
        if content:
            kwargs["content"] = content[:2000]
        if embed is not None:
            kwargs["embed"] = embed
        if view is not None:
            kwargs["view"] = view

        if use_webhook:
            hook = await self.get_webhook(channel)
            name = username or self.cfg.get("webhook_name") or None
            avatar = avatar_url or self.cfg.get("webhook_avatar_url") or None
            if name:
                kwargs["username"] = name[:80]
            if avatar:
                kwargs["avatar_url"] = avatar
            try:
                msg = await hook.send(wait=True, **kwargs)
            except discord.NotFound:
                # вебхук удалили руками — создаём заново
                self.forget_webhook(channel.id)
                hook = await self.get_webhook(channel)
                msg = await hook.send(wait=True, **kwargs)
            except (discord.HTTPException, ValueError, TypeError) as e:
                if "view" not in kwargs:
                    raise
                log.warning("Вебхук не принял кнопки (%s), шлю без них", e)
                kwargs.pop("view")
                msg = await hook.send(wait=True, **kwargs)
            ref = SentRef(channel.id, msg.id, True, msg.jump_url)
        else:
            msg = await channel.send(**kwargs)
            ref = SentRef(channel.id, msg.id, False, msg.jump_url)
            # В канале-объявлениях можно сразу опубликовать — подписанные серверы тоже увидят
            if self.cfg.get("auto_publish", False) and getattr(channel, "is_news", lambda: False)():
                try:
                    await msg.publish()
                except discord.HTTPException as e:
                    log.warning("Не смог опубликовать сообщение: %s", e)
        return ref

    async def edit(
        self,
        channel_id: int,
        message_id: int,
        via_webhook: bool,
        *,
        content=MISSING,
        embed=MISSING,
        view=MISSING,
    ) -> None:
        channel = await self.get_channel(int(channel_id))
        kwargs = {}
        if content is not MISSING:
            kwargs["content"] = content
        if embed is not MISSING:
            kwargs["embed"] = embed
        if view is not MISSING:
            kwargs["view"] = view
        if via_webhook:
            hook = await self.get_webhook(channel)
            await hook.edit_message(int(message_id), **kwargs)
        else:
            await channel.get_partial_message(int(message_id)).edit(**kwargs)

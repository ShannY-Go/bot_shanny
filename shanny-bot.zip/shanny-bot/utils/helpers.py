"""Discord-хелперы: кнопки-ссылки, упоминания, проверка настроек."""
import discord

# Разрешаем боту пинговать роли/@everyone в уведомлениях
ALLOW_PINGS = discord.AllowedMentions(everyone=True, roles=True, users=True)
NO_PINGS = discord.AllowedMentions.none()

# Ключ в [links] -> (подпись, эмодзи)
LINK_META = {
    "youtube": ("YouTube", "▶️"),
    "twitch": ("Twitch", "🟣"),
    "tiktok": ("TikTok", "🎵"),
    "telegram": ("Telegram", "✈️"),
    "vk": ("VK", "💬"),
    "boosty": ("Boosty", "💸"),
    "donate": ("Донат", "💰"),
    "site": ("Сайт", "🌐"),
}


def link_view(*buttons: tuple[str, str, str | None]) -> discord.ui.View | None:
    """Вьюха с кнопками-ссылками: (подпись, url, эмодзи)."""
    view = discord.ui.View(timeout=None)
    added = 0
    for label, url, emoji in buttons:
        if not url or not str(url).startswith(("http://", "https://")):
            continue
        view.add_item(discord.ui.Button(label=label[:80], url=url, emoji=emoji or None))
        added += 1
        if added >= 25:
            break
    return view if added else None


def social_links_view(links: dict) -> discord.ui.View | None:
    buttons = []
    for key, url in (links or {}).items():
        if not url:
            continue
        label, emoji = LINK_META.get(key, (key.capitalize(), "🔗"))
        buttons.append((label, url, emoji))
    return link_view(*buttons)


BUTTON_STYLES = {
    "red": discord.ButtonStyle.danger,
    "green": discord.ButtonStyle.success,
    "blue": discord.ButtonStyle.primary,
    "grey": discord.ButtonStyle.secondary,
    "gray": discord.ButtonStyle.secondary,
}

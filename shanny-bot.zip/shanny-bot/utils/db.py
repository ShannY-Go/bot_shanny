"""Маленькая SQLite-база: какие видосы уже запостили, состояние стримов и т.п."""
import os
import sqlite3
import time

SCHEMA = """
CREATE TABLE IF NOT EXISTS kv (
    key   TEXT PRIMARY KEY,
    value TEXT
);
CREATE TABLE IF NOT EXISTS yt_seen (
    video_id   TEXT PRIMARY KEY,
    channel_id TEXT,
    kind       TEXT,
    seen_at    INTEGER
);
CREATE TABLE IF NOT EXISTS yt_pending (
    video_id   TEXT PRIMARY KEY,
    channel_id TEXT,
    added_at   INTEGER
);
CREATE TABLE IF NOT EXISTS yt_channels (
    key        TEXT PRIMARY KEY,
    channel_id TEXT,
    avatar     TEXT,
    title      TEXT,
    updated_at INTEGER
);
CREATE TABLE IF NOT EXISTS twitch_state (
    login       TEXT PRIMARY KEY,
    live        INTEGER DEFAULT 0,
    stream_id   TEXT,
    channel_id  INTEGER,
    message_id  INTEGER,
    via_webhook INTEGER DEFAULT 0,
    started_at  TEXT,
    ended_at    INTEGER,
    title       TEXT,
    game        TEXT
);
"""


class DB:
    def __init__(self, path: str):
        folder = os.path.dirname(path)
        if folder:
            os.makedirs(folder, exist_ok=True)
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    # --- базовое ---
    def execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        cur = self.conn.execute(sql, params)
        self.conn.commit()
        return cur

    def one(self, sql: str, params: tuple = ()):
        return self.conn.execute(sql, params).fetchone()

    def all(self, sql: str, params: tuple = ()):
        return self.conn.execute(sql, params).fetchall()

    def close(self):
        self.conn.close()

    # --- key/value ---
    def kv_get(self, key: str, default=None):
        row = self.one("SELECT value FROM kv WHERE key = ?", (key,))
        return row["value"] if row else default

    def kv_set(self, key: str, value) -> None:
        self.execute(
            "INSERT INTO kv(key, value) VALUES(?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, str(value)),
        )

    # --- YouTube ---
    def yt_is_seen(self, video_id: str) -> bool:
        return self.one("SELECT 1 FROM yt_seen WHERE video_id = ?", (video_id,)) is not None

    def yt_mark_seen(self, video_id: str, channel_id: str, kind: str) -> None:
        self.execute(
            "INSERT OR REPLACE INTO yt_seen(video_id, channel_id, kind, seen_at) VALUES(?, ?, ?, ?)",
            (video_id, channel_id, kind, int(time.time())),
        )

    def yt_seen_count(self, channel_id: str) -> int:
        row = self.one("SELECT COUNT(*) AS c FROM yt_seen WHERE channel_id = ?", (channel_id,))
        return row["c"] if row else 0

    def yt_pending_ids(self, channel_id: str) -> set[str]:
        rows = self.all("SELECT video_id FROM yt_pending WHERE channel_id = ?", (channel_id,))
        return {r["video_id"] for r in rows}

    def yt_pending_add(self, video_id: str, channel_id: str) -> None:
        self.execute(
            "INSERT OR IGNORE INTO yt_pending(video_id, channel_id, added_at) VALUES(?, ?, ?)",
            (video_id, channel_id, int(time.time())),
        )

    def yt_pending_remove(self, video_id: str) -> None:
        self.execute("DELETE FROM yt_pending WHERE video_id = ?", (video_id,))

    def yt_pending_cleanup(self, max_age_seconds: int) -> None:
        self.execute("DELETE FROM yt_pending WHERE added_at < ?", (int(time.time()) - max_age_seconds,))

    def yt_channel_get(self, key: str):
        return self.one("SELECT * FROM yt_channels WHERE key = ?", (key,))

    def yt_channel_set(self, key: str, channel_id: str, avatar: str | None, title: str | None) -> None:
        self.execute(
            "INSERT OR REPLACE INTO yt_channels(key, channel_id, avatar, title, updated_at) VALUES(?, ?, ?, ?, ?)",
            (key, channel_id, avatar, title, int(time.time())),
        )

    # --- Twitch ---
    def tw_get(self, login: str):
        return self.one("SELECT * FROM twitch_state WHERE login = ?", (login.lower(),))

    def tw_set(self, login: str, **fields) -> None:
        login = login.lower()
        if self.tw_get(login) is None:
            self.execute("INSERT INTO twitch_state(login) VALUES(?)", (login,))
        if fields:
            cols = ", ".join(f"{k} = ?" for k in fields)
            self.execute(f"UPDATE twitch_state SET {cols} WHERE login = ?", (*fields.values(), login))

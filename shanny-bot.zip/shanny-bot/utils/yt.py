"""
Работа с YouTube без лишних зависимостей.
Основной способ — RSS-лента канала (бесплатно, без ключа).
Если есть YOUTUBE_API_KEY — используем API для точности и как запасной вариант.
"""
import html
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from datetime import datetime

import aiohttp

from .text import parse_iso

NS = {
    "atom": "http://www.w3.org/2005/Atom",
    "yt": "http://www.youtube.com/xml/schemas/2015",
    "media": "http://search.yahoo.com/mrss/",
}
API = "https://www.googleapis.com/youtube/v3"
# Чтобы ютуб не подсовывал страницу согласия с куками
CONSENT_HEADERS = {"Cookie": "CONSENT=YES+cb; SOCS=CAI"}
CHANNEL_ID_RE = re.compile(r"^UC[\w-]{22}$")


@dataclass
class YTVideo:
    id: str
    title: str
    url: str
    author: str
    channel_id: str
    published: datetime | None
    thumbnail: str
    description: str
    short_hint: bool = False  # ссылка в ленте ведёт на /shorts/

    @property
    def watch_url(self) -> str:
        return f"https://www.youtube.com/watch?v={self.id}"

    @property
    def shorts_url(self) -> str:
        return f"https://www.youtube.com/shorts/{self.id}"


# ---------------------------------------------------------------- RSS --
def parse_feed(xml_text: str) -> list[YTVideo]:
    """Парсит RSS ленту канала. Возвращает видосы от новых к старым."""
    root = ET.fromstring(xml_text)
    videos: list[YTVideo] = []
    feed_author = root.findtext("atom:author/atom:name", default="", namespaces=NS)
    for entry in root.findall("atom:entry", NS):
        vid = entry.findtext("yt:videoId", default="", namespaces=NS)
        if not vid:
            continue
        link_el = entry.find("atom:link[@rel='alternate']", NS)
        link = link_el.get("href") if link_el is not None else f"https://www.youtube.com/watch?v={vid}"
        thumb_el = entry.find("media:group/media:thumbnail", NS)
        thumb = thumb_el.get("url") if thumb_el is not None else f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"
        videos.append(
            YTVideo(
                id=vid,
                title=entry.findtext("atom:title", default="", namespaces=NS),
                url=link,
                author=entry.findtext("atom:author/atom:name", default=feed_author, namespaces=NS),
                channel_id=entry.findtext("yt:channelId", default="", namespaces=NS),
                published=parse_iso(entry.findtext("atom:published", default="", namespaces=NS)),
                thumbnail=thumb,
                description=entry.findtext("media:group/media:description", default="", namespaces=NS),
                short_hint="/shorts/" in link,
            )
        )
    return videos


async def fetch_feed(session: aiohttp.ClientSession, channel_id: str) -> list[YTVideo]:
    url = f"https://www.youtube.com/feeds/videos.xml?channel_id={channel_id}"
    async with session.get(url) as r:
        if r.status != 200:
            raise RuntimeError(f"RSS ютуба ответил {r.status}")
        return parse_feed(await r.text())


# ------------------------------------------------------- Поиск канала --
def _normalize_handle(value: str) -> str:
    """'https://youtube.com/@Nick/videos' -> '@Nick';  'Nick' -> '@Nick'"""
    value = value.strip()
    m = re.search(r"youtube\.com/(@[\w.\-]+)", value)
    if m:
        return m.group(1)
    m = re.search(r"youtube\.com/channel/(UC[\w-]{22})", value)
    if m:
        return m.group(1)
    if CHANNEL_ID_RE.match(value):
        return value
    return value if value.startswith("@") else "@" + value


def parse_channel_page(page: str) -> tuple[str | None, str | None, str | None]:
    """Из HTML страницы канала достаёт (channel_id, avatar_url, title)."""
    cid = None
    for pattern in (
        r'<link rel="canonical" href="https://www\.youtube\.com/channel/(UC[\w-]{22})"',
        r'"externalId":"(UC[\w-]{22})"',
        r'<meta itemprop="identifier" content="(UC[\w-]{22})"',
        r'"channelId":"(UC[\w-]{22})"',
    ):
        m = re.search(pattern, page)
        if m:
            cid = m.group(1)
            break
    avatar = None
    m = re.search(r'<meta property="og:image" content="([^"]+)"', page)
    if m:
        avatar = html.unescape(m.group(1))
    title = None
    m = re.search(r'<meta property="og:title" content="([^"]+)"', page)
    if m:
        title = html.unescape(m.group(1))
    return cid, avatar, title


async def resolve_channel(
    session: aiohttp.ClientSession, handle_or_id: str, api_key: str | None = None
) -> tuple[str, str | None, str | None]:
    """@ник / ссылка / UC-id -> (channel_id, avatar_url, title)."""
    key = _normalize_handle(handle_or_id)

    if api_key:
        params = {"part": "snippet", "key": api_key}
        if CHANNEL_ID_RE.match(key):
            params["id"] = key
        else:
            params["forHandle"] = key
        try:
            async with session.get(f"{API}/channels", params=params) as r:
                data = await r.json()
            items = data.get("items") or []
            if items:
                sn = items[0].get("snippet", {})
                thumbs = sn.get("thumbnails", {})
                avatar = (thumbs.get("high") or thumbs.get("default") or {}).get("url")
                return items[0]["id"], avatar, sn.get("title")
        except (aiohttp.ClientError, ValueError, KeyError):
            pass  # пробуем через страницу

    url = f"https://www.youtube.com/channel/{key}" if CHANNEL_ID_RE.match(key) else f"https://www.youtube.com/{key}"
    async with session.get(url, headers=CONSENT_HEADERS) as r:
        if r.status != 200:
            raise RuntimeError(f"Не нашёл канал {key} (ютуб ответил {r.status})")
        page = await r.text()
    cid, avatar, title = parse_channel_page(page)
    if CHANNEL_ID_RE.match(key):
        cid = key
    if not cid:
        raise RuntimeError(f"Не смог вытащить ID канала {key}. Впиши channel_id вручную в config.toml")
    return cid, avatar, title


# ----------------------------------------------- Что это: видос/шортс/стрим --
# Шортсы на ютубе могут идти до 3 минут (с октября 2024), поэтому порог с запасом
SHORT_MAX_SECONDS = 190
_DURATION_RE = re.compile(r"^PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?$")


def parse_iso_duration(value: str | None) -> int | None:
    """'PT1M5S' -> 65 секунд."""
    m = _DURATION_RE.match(value or "")
    if not m or not any(m.groups()):
        return None
    h, mi, sec = (int(x or 0) for x in m.groups())
    return h * 3600 + mi * 60 + sec


async def short_probe(session: aiohttp.ClientSession, video_id: str) -> bool | None:
    """
    Шортс открывается по /shorts/ID (200), обычный видос редиректит на /watch.
    True / False — уверенный ответ, None — ютуб ответил чем-то странным (капча, лимит, сеть).
    """
    try:
        async with session.get(
            f"https://www.youtube.com/shorts/{video_id}", allow_redirects=False, headers=CONSENT_HEADERS
        ) as r:
            if r.status == 200:
                return True
            if r.status in (301, 302, 303, 307, 308) and "/watch" in r.headers.get("Location", ""):
                return False
            return None
    except aiohttp.ClientError:
        return None


async def is_short(session: aiohttp.ClientSession, video_id: str) -> bool:
    return (await short_probe(session, video_id)) is True


async def api_duration(session: aiohttp.ClientSession, video_id: str, api_key: str) -> int | None:
    """Длина видео в секундах через API (1 единица квоты)."""
    try:
        params = {"part": "contentDetails", "id": video_id, "key": api_key}
        async with session.get(f"{API}/videos", params=params) as r:
            data = await r.json()
        items = data.get("items") or []
        return parse_iso_duration(items[0].get("contentDetails", {}).get("duration")) if items else None
    except (aiohttp.ClientError, ValueError):
        return None


def parse_live_state(page: str) -> str:
    """По HTML страницы видео: 'live' / 'upcoming' / 'none'."""
    if '"isLiveNow":true' in page:
        return "live"
    # смотрим только кусок videoDetails основного видео, чтоб не зацепить рекомендации
    i = page.find('"videoDetails":{')
    chunk = page[i : i + 6000] if i != -1 else ""
    if '"isUpcoming":true' in chunk:
        return "upcoming"
    return "none"


async def live_state(session: aiohttp.ClientSession, video_id: str, api_key: str | None = None) -> str:
    if api_key:
        try:
            params = {"part": "snippet", "id": video_id, "key": api_key}
            async with session.get(f"{API}/videos", params=params) as r:
                data = await r.json()
            items = data.get("items") or []
            if items:
                state = items[0].get("snippet", {}).get("liveBroadcastContent", "none")
                return state if state in ("live", "upcoming") else "none"
        except (aiohttp.ClientError, ValueError):
            pass
    try:
        async with session.get(f"https://www.youtube.com/watch?v={video_id}", headers=CONSENT_HEADERS) as r:
            if r.status != 200:
                return "none"
            return parse_live_state(await r.text())
    except aiohttp.ClientError:
        return "none"


async def classify(session: aiohttp.ClientSession, video: YTVideo, api_key: str | None = None) -> str:
    """'video' / 'short' / 'live' / 'upcoming'."""
    if not video.short_hint:
        state = await live_state(session, video.id, api_key)
        if state in ("live", "upcoming"):
            return state
    if video.short_hint:
        return "short"

    probe = await short_probe(session, video.id)
    if probe is False:
        return "video"
    # Тут ютуб либо сказал «шортс», либо ответил непонятно — сверяемся с длиной ролика (нужен API-ключ)
    duration = await api_duration(session, video.id, api_key) if api_key else None
    if probe is True:
        # Страховка от ложного «шортс»: ролик длиннее 3 минут шортсом быть не может
        return "short" if duration is None or duration <= SHORT_MAX_SECONDS else "video"
    return "short" if duration is not None and duration <= 60 else "video"


# ------------------------------------------------------------ API-штуки --
async def api_uploads(session: aiohttp.ClientSession, channel_id: str, api_key: str) -> list[YTVideo]:
    """Запасной способ получить последние загрузки, если RSS лёг."""
    playlist = "UU" + channel_id[2:]
    params = {"part": "snippet", "playlistId": playlist, "maxResults": 10, "key": api_key}
    async with session.get(f"{API}/playlistItems", params=params) as r:
        data = await r.json()
    if "error" in data:
        raise RuntimeError(f"YouTube API: {data['error'].get('message')}")
    videos = []
    for item in data.get("items", []):
        sn = item.get("snippet", {})
        vid = sn.get("resourceId", {}).get("videoId")
        if not vid:
            continue
        thumbs = sn.get("thumbnails", {})
        thumb = (thumbs.get("maxres") or thumbs.get("high") or thumbs.get("default") or {}).get("url", "")
        videos.append(
            YTVideo(
                id=vid,
                title=sn.get("title", ""),
                url=f"https://www.youtube.com/watch?v={vid}",
                author=sn.get("channelTitle", ""),
                channel_id=channel_id,
                published=parse_iso(sn.get("publishedAt")),
                thumbnail=thumb,
                description=sn.get("description", ""),
            )
        )
    videos.sort(key=lambda v: v.published.timestamp() if v.published else 0, reverse=True)
    return videos


async def api_subscribers(session: aiohttp.ClientSession, channel_id: str, api_key: str) -> int | None:
    params = {"part": "statistics", "id": channel_id, "key": api_key}
    async with session.get(f"{API}/channels", params=params) as r:
        data = await r.json()
    items = data.get("items") or []
    if not items:
        return None
    stats = items[0].get("statistics", {})
    if stats.get("hiddenSubscriberCount"):
        return None
    try:
        return int(stats.get("subscriberCount"))
    except (TypeError, ValueError):
        return None

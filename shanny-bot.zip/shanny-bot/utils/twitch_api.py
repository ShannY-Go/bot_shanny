"""Мини-клиент Twitch Helix API (app access token, без OAuth пользователя)."""
import time

import aiohttp

TOKEN_URL = "https://id.twitch.tv/oauth2/token"
HELIX = "https://api.twitch.tv/helix"


class TwitchError(RuntimeError):
    pass


class TwitchAPI:
    def __init__(self, session: aiohttp.ClientSession, client_id: str, client_secret: str):
        self.session = session
        self.client_id = client_id
        self.client_secret = client_secret
        self._token: str | None = None
        self._expires = 0.0

    async def _get_token(self) -> str:
        if self._token and time.time() < self._expires - 120:
            return self._token
        data = {
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "grant_type": "client_credentials",
        }
        async with self.session.post(TOKEN_URL, data=data) as r:
            payload = await r.json(content_type=None)
            if r.status != 200 or "access_token" not in payload:
                raise TwitchError(f"Twitch не выдал токен: {payload.get('message', r.status)}. Проверь CLIENT_ID/SECRET")
        self._token = payload["access_token"]
        self._expires = time.time() + float(payload.get("expires_in", 3600))
        return self._token

    async def get(self, path: str, params) -> dict:
        for attempt in range(2):
            token = await self._get_token()
            headers = {"Client-ID": self.client_id, "Authorization": f"Bearer {token}"}
            async with self.session.get(f"{HELIX}/{path}", params=params, headers=headers) as r:
                if r.status == 401 and attempt == 0:
                    self._token = None  # токен протух — берём новый
                    continue
                payload = await r.json(content_type=None)
                if r.status != 200:
                    raise TwitchError(f"Twitch API {r.status}: {payload.get('message')}")
                return payload
        raise TwitchError("Twitch не принимает токен")

    async def streams(self, logins: list[str]) -> dict[str, dict]:
        """login -> данные стрима (только для тех, кто сейчас в эфире)."""
        if not logins:
            return {}
        params = [("user_login", l.lower()) for l in logins[:100]] + [("first", "100")]
        data = await self.get("streams", params)
        return {s["user_login"].lower(): s for s in data.get("data", []) if s.get("type") == "live"}

    async def users(self, logins: list[str]) -> dict[str, dict]:
        if not logins:
            return {}
        params = [("login", l.lower()) for l in logins[:100]]
        data = await self.get("users", params)
        return {u["login"].lower(): u for u in data.get("data", [])}

    async def follower_count(self, login: str) -> int:
        """Сколько у канала фолловеров (хватает токена приложения, без OAuth стримера)."""
        users = await self.users([login])
        user = users.get(login.lower())
        if not user:
            raise TwitchError(f"Твич не знает канал «{login}» — проверь ник")
        data = await self.get("channels/followers", [("broadcaster_id", user["id"]), ("first", "1")])
        return int(data["total"])


async def decapi_follower_count(session: aiohttp.ClientSession, login: str) -> int | None:
    """
    Запасной способ без ключей Твича: бесплатный публичный сервис decapi.me.
    Возвращает None, если сервис ответил не числом.
    """
    async with session.get(f"https://decapi.me/twitch/followcount/{login.lower()}") as r:
        if r.status != 200:
            return None
        text = (await r.text()).strip().replace(",", "").replace(" ", "")
    return int(text) if text.isdigit() else None

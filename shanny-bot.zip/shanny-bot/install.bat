@echo off
cd /d "%~dp0"

where python >nul 2>nul
if errorlevel 1 (
    echo [!] Python not found. Install Python 3.11+ from python.org
    echo     and tick "Add Python to PATH" in the installer.
    pause
    exit /b 1
)

echo === Creating virtual environment...
python -m venv venv
if errorlevel 1 (
    echo [!] Could not create venv.
    pause
    exit /b 1
)
call venv\Scripts\activate.bat

echo === Installing packages...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo [!] Package install failed. Check internet / VPN and run install.bat again.
    pause
    exit /b 1
)

if not exist .env (
    copy .env.example .env >nul
    echo === Created .env file
)

echo.
echo === DONE! Next steps:
echo    1. Open .env and paste your bot token and keys
echo    2. Open config.toml and fill in channel and role IDs
echo    3. Run start.bat
echo.
pause

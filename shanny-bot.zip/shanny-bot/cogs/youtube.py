"""Уведомления о новых роликах, шортсах и стримах на YouTube."""
import asyncio
import logging
from datetime import datetime, timedelta, timezone

import discord
from discord import app_commands
from discord.ext import commands, tasks

from utils import yt
from utils.helpers import link_view
from utils.text import is_set, md_escape, ping_text, render, shorten

log = logging.getLogger("youtube")

KIND_LABEL = {"video": "Новое видео", "short": "Shorts", "live": "Прямой эфир"}
KIND_BUTTON = {"video": "Смотреть", "short": "Смотреть шортс", "live": "Залететь на стрим"}
KIND_EMOJI = {"video": "▶️", "short": "⚡", "live": "🔴"}
YT_RED = 0xFF0033


class YouTube(commands.Cog):
    yt_admin = app_commands.Group(
        name="youtube",
        description="Настройка уведомлений с YouTube",
        default_permissions=discord.Permissions(manage_guild=True),
        guild_only=True,
    )

    def __init__(self, bot):
        self.bot = bot
        self.cfg: dict = bot.cfg.get("youtube", {})
        self.api_key: str | None = bot.env.get("YOUTUBE_API_KEY") or None
        self.lock = asyncio.Lock()

    @property
    def channels(self) -> list[dict]:
        return self.cfg.get("channels", [])

    async def cog_load(self):
        if not self.channels:
            log.warning("В [youtube] нет ни одного канала — проверка не запущена")
            return
        minutes = max(1.0, float(self.cfg.get("check_interval_minutes", 5)))
        self.check_loop.change_interval(minutes=minutes)
        self.check_loop.start()

    async def cog_unload(self):
        self.check_loop.cancel()

    # ------------------------------------------------------------ цикл --
    @tasks.loop(minutes=5)
    async def check_loop(self):
        try:
            await self.check_all()
        except Exception:
            log.exception("Ошибка при проверке YouTube")

    @check_loop.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()

    async def check_all(self) -> int:
        async with self.lock:
            posted = 0
            for ch in self.channels:
                try:
                    posted += await self.check_channel(ch)
                except Exception as e:
                    log.warning("Канал %s: %s", ch.get("handle") or ch.get("channel_id"), e)
            return posted

    async def resolve(self, ch: dict) -> tuple[str, str | None, str | None]:
        source = (ch.get("channel_id") or ch.get("handle") or "").strip()
        if not source:
            raise RuntimeError("у канала не задан ни handle, ни channel_id")
        cached = self.bot.db.yt_channel_get(source)
        if cached:
            return cached["channel_id"], cached["avatar"], cached["title"]
        cid, avatar, title = await yt.resolve_channel(self.bot.http_session, source, self.api_key)
        self.bot.db.yt_channel_set(source, cid, avatar, title)
        log.info("Канал %s → %s (%s)", source, cid, title)
        return cid, avatar, title

    async def fetch_videos(self, channel_id: str) -> list[yt.YTVideo]:
        try:
            videos = await yt.fetch_feed(self.bot.http_session, channel_id)
        except Exception as e:
            if not self.api_key:
                raise
            log.info("RSS не отдал ленту (%s), беру через API", e)
            videos = await yt.api_uploads(self.bot.http_session, channel_id, self.api_key)
        for v in videos:
            if not v.channel_id.startswith("UC"):
                v.channel_id = channel_id
        return videos

    async def check_channel(self, ch: dict) -> int:
        if not is_set(ch.get("discord_channel_id")):
            return 0
        db = self.bot.db
        cid, avatar, _ = await self.resolve(ch)
        videos = await self.fetch_videos(cid)

        # Первый запуск: просто запоминаем всё, что уже есть, чтоб не заспамить
        seed_key = f"yt_seeded:{cid}"
        if not db.kv_get(seed_key):
            for v in videos:
                db.yt_mark_seen(v.id, cid, "seed")
            db.kv_set(seed_key, "1")
            log.info("Первый запуск для %s: запомнил %d старых видео, постить не буду", cid, len(videos))
            return 0

        pending = db.yt_pending_ids(cid)
        max_age = timedelta(hours=float(self.cfg.get("max_age_hours", 48)))
        now = datetime.now(timezone.utc)
        posted = 0

        for v in reversed(videos):  # от старых к новым
            if db.yt_is_seen(v.id):
                continue
            if v.id not in pending and v.published and now - v.published > max_age:
                db.yt_mark_seen(v.id, cid, "old")
                continue

            kind = await yt.classify(self.bot.http_session, v, self.api_key)
            if kind == "upcoming":
                # запланированный стрим/премьера — ждём, пока начнётся
                if v.id not in pending:
                    db.yt_pending_add(v.id, cid)
                    log.info("Запланирован эфир/премьера: %s — жду начала", v.title)
                continue
            if kind == "short" and not ch.get("post_shorts", True):
                db.yt_mark_seen(v.id, cid, "short-skipped")
                db.yt_pending_remove(v.id)
                continue

            await self.post(ch, v, kind, avatar)
            db.yt_mark_seen(v.id, cid, kind)
            db.yt_pending_remove(v.id)
            posted += 1

        db.yt_pending_cleanup(14 * 24 * 3600)
        return posted

    # ------------------------------------------------------- сообщение --
    def build(self, ch: dict, v: yt.YTVideo, kind: str, avatar: str | None, with_ping: bool = True):
        name = ch.get("name") or v.author or "Канал"
        url = v.shorts_url if kind == "short" else v.watch_url
        ping = ping_text(ch.get(f"ping_{kind}")) if with_ping else ""
        template = ch.get(f"message_{kind}") or "{ping} {title}"
        content = render(
            template,
            ping=ping,
            title=md_escape(v.title),  # скобки и звёздочки в названии не должны ломать разметку
            url=url,
            channel=name,
            description=shorten(v.description, 200),
        )
        style = ch.get("style", "embed")
        # Кнопка «Смотреть» под сообщением: по умолчанию есть у карточки и нет у обычного сообщения со ссылкой
        want_button = ch.get("button", style != "native")
        view = link_view((KIND_BUTTON[kind], url, KIND_EMOJI[kind])) if want_button else None

        if style == "native":
            if url not in content:
                content = f"{content}\n{url}".strip()
            return content, None, view

        embed = discord.Embed(
            title=shorten(v.title, 256),
            url=url,
            description=shorten(v.description, 300) or None,
            color=YT_RED,
            timestamp=v.published or discord.utils.utcnow(),
        )
        embed.set_author(
            name=name,
            url=f"https://www.youtube.com/channel/{v.channel_id}" if v.channel_id else None,
            icon_url=avatar or None,
        )
        if v.thumbnail:
            embed.set_image(url=v.thumbnail)
        embed.set_footer(text=f"YouTube • {KIND_LABEL[kind]}")
        return content or None, embed, view

    async def post(self, ch: dict, v: yt.YTVideo, kind: str, avatar: str | None):
        content, embed, view = self.build(ch, v, kind, avatar)
        ref = await self.bot.notifier.send(int(ch["discord_channel_id"]), content=content, embed=embed, view=view)
        log.info("Запостил [%s] %s", kind, v.title)
        await self.bot.log_event(f"📺 Уведомление [{KIND_LABEL[kind]}]: **{v.title}** → {ref.jump_url}")

    async def latest(self, ch: dict, skip_shorts: bool = True) -> tuple[yt.YTVideo | None, str, str | None]:
        cid, avatar, _ = await self.resolve(ch)
        videos = await self.fetch_videos(cid)
        for v in videos[:8]:
            kind = await yt.classify(self.bot.http_session, v, self.api_key)
            if kind == "upcoming" or (skip_shorts and kind == "short"):
                continue
            return v, kind, avatar
        if videos:
            return videos[0], "video", avatar
        return None, "video", avatar

    # ------------------------------------------------------- команды --
    @app_commands.command(name="last", description="Последний ролик на канале")
    async def last(self, interaction: discord.Interaction):
        if not self.channels:
            return await interaction.response.send_message("Каналы не настроены.", ephemeral=True)
        await interaction.response.defer(thinking=True)
        v, kind, avatar = await self.latest(self.channels[0])
        if not v:
            return await interaction.followup.send("На канале пока пусто 🤷")
        _, embed, view = self.build(self.channels[0], v, kind, avatar, with_ping=False)
        if embed is None:  # style = native
            return await interaction.followup.send(v.watch_url, view=view or discord.utils.MISSING)
        await interaction.followup.send(embed=embed, view=view or discord.utils.MISSING)

    @yt_admin.command(name="test", description="Показать, как будет выглядеть уведомление (на последнем ролике)")
    @app_commands.describe(
        real="Отправить по-настоящему в канал уведомлений (с пингом)",
        shorts="Взять последний шортс, а не видео",
    )
    async def cmd_test(self, interaction: discord.Interaction, real: bool = False, shorts: bool = False):
        if not self.channels:
            return await interaction.response.send_message("Каналы не настроены.", ephemeral=True)
        await interaction.response.defer(ephemeral=True, thinking=True)
        ch = self.channels[0]
        if shorts:
            cid, avatar, _ = await self.resolve(ch)
            videos = await self.fetch_videos(cid)
            v = None
            for item in videos[:10]:
                if item.short_hint or await yt.is_short(self.bot.http_session, item.id):
                    v = item
                    break
            kind = "short"
        else:
            v, kind, avatar = await self.latest(ch)
        if not v:
            return await interaction.followup.send("Не нашёл подходящий ролик на канале.", ephemeral=True)

        if real:
            if not is_set(ch.get("discord_channel_id")):
                return await interaction.followup.send("Не задан discord_channel_id в конфиге.", ephemeral=True)
            await self.post(ch, v, kind, avatar)
            return await interaction.followup.send("Отправил в канал уведомлений ✅", ephemeral=True)

        content, embed, view = self.build(ch, v, kind, avatar)
        kwargs = {"ephemeral": True}
        if embed:
            kwargs["embed"] = embed
        if view:
            kwargs["view"] = view
        await interaction.followup.send(content=f"**Превью** (пинг тут не сработает):\n{content or ''}", **kwargs)

    @yt_admin.command(name="check", description="Проверить новые ролики прямо сейчас")
    async def cmd_check(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        posted = await self.check_all()
        await interaction.followup.send(
            f"Готово. Новых уведомлений: **{posted}**" if posted else "Проверил — новых роликов нет.",
            ephemeral=True,
        )

    @yt_admin.command(name="channels", description="Какие каналы отслеживаются")
    async def list_channels(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True, thinking=True)
        lines = []
        for ch in self.channels:
            source = ch.get("channel_id") or ch.get("handle")
            try:
                cid, _, title = await self.resolve(ch)
                target = f"<#{ch['discord_channel_id']}>" if is_set(ch.get("discord_channel_id")) else "⚠️ канал не задан"
                lines.append(
                    f"• **{title or source}** (`{cid}`) → {target} · в базе {self.bot.db.yt_seen_count(cid)} видео"
                )
            except Exception as e:
                lines.append(f"• {source}: ❌ {e}")
        await interaction.followup.send("\n".join(lines) or "Каналов нет.", ephemeral=True)


async def setup(bot):
    await bot.add_cog(YouTube(bot))

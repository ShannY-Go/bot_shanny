"""Уведомления о стримах на Twitch: пинг на старте, правка сообщения после конца."""
import asyncio
import logging
import time

import discord
from discord import app_commands
from discord.ext import commands, tasks

from utils.helpers import link_view
from utils.text import fmt_duration, fmt_number, is_set, parse_iso, ping_text, render, shorten
from utils.twitch_api import TwitchAPI

log = logging.getLogger("twitch")
TWITCH_PURPLE = 0x9146FF
OFFLINE_GREY = 0x2B2D31


class Twitch(commands.Cog):
    tw_admin = app_commands.Group(
        name="twitch",
        description="Настройка уведомлений с Twitch",
        default_permissions=discord.Permissions(manage_guild=True),
        guild_only=True,
    )

    def __init__(self, bot):
        self.bot = bot
        self.cfg: dict = bot.cfg.get("twitch", {})
        self.api: TwitchAPI | None = None
        self.users: dict[str, dict] = {}
        self.lock = asyncio.Lock()

    @property
    def streamers(self) -> list[dict]:
        return [s for s in self.cfg.get("streamers", []) if s.get("login") and "впиши" not in s["login"]]

    async def cog_load(self):
        cid, secret = self.bot.env.get("TWITCH_CLIENT_ID"), self.bot.env.get("TWITCH_CLIENT_SECRET")
        if not cid or not secret:
            log.warning("Нет TWITCH_CLIENT_ID / TWITCH_CLIENT_SECRET в .env — уведомления с твича выключены")
            return
        if not self.streamers:
            log.warning("В [twitch] не указан ник стримера — уведомления с твича выключены")
            return
        self.api = TwitchAPI(self.bot.http_session, cid, secret)
        seconds = max(30.0, float(self.cfg.get("check_interval_seconds", 60)))
        self.check_loop.change_interval(seconds=seconds)
        self.check_loop.start()

    async def cog_unload(self):
        self.check_loop.cancel()

    # ------------------------------------------------------------ цикл --
    @tasks.loop(seconds=60)
    async def check_loop(self):
        try:
            await self.check_all()
        except Exception:
            log.exception("Ошибка при проверке Twitch")

    @check_loop.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()

    async def get_user(self, login: str) -> dict:
        login = login.lower()
        if login not in self.users:
            self.users.update(await self.api.users([login]))
        return self.users.get(login, {})

    async def check_all(self) -> None:
        if not self.api:
            return
        async with self.lock:
            logins = [s["login"].lower() for s in self.streamers]
            live = await self.api.streams(logins)
            for s in self.streamers:
                login = s["login"].lower()
                try:
                    if login in live:
                        await self.handle_live(s, live[login])
                    else:
                        await self.handle_offline(s)
                except Exception:
                    log.exception("Стример %s", login)

    async def handle_live(self, s: dict, stream: dict) -> None:
        db = self.bot.db
        login = s["login"].lower()
        state = db.tw_get(login)

        # Тот же стрим, уже запостили
        if state and state["live"] and state["stream_id"] == stream["id"]:
            return

        user = await self.get_user(login)
        content, embed, view = self.build_live(s, stream, user)
        grace = float(self.cfg.get("reconnect_grace_minutes", 10)) * 60

        # Стрим упал и поднялся быстро — не пингуем второй раз, просто оживляем старое сообщение
        if (
            state
            and not state["live"]
            and state["message_id"]
            and state["ended_at"]
            and time.time() - state["ended_at"] < grace
        ):
            try:
                await self.bot.notifier.edit(
                    state["channel_id"], state["message_id"], bool(state["via_webhook"]), embed=embed, view=view
                )
                db.tw_set(login, live=1, stream_id=stream["id"], title=stream.get("title"), game=stream.get("game_name"))
                log.info("%s переподключился — обновил старое уведомление", login)
                return
            except discord.HTTPException:
                pass  # сообщение удалили — шлём новое

        if not is_set(s.get("discord_channel_id")):
            return
        ref = await self.bot.notifier.send(int(s["discord_channel_id"]), content=content, embed=embed, view=view)
        db.tw_set(
            login,
            live=1,
            stream_id=stream["id"],
            channel_id=ref.channel_id,
            message_id=ref.message_id,
            via_webhook=int(ref.via_webhook),
            started_at=stream.get("started_at"),
            ended_at=None,
            title=stream.get("title"),
            game=stream.get("game_name"),
        )
        log.info("Стрим начался: %s — %s", login, stream.get("title"))
        await self.bot.log_event(f"🟣 Стрим **{stream.get('user_name')}** начался → {ref.jump_url}")

    async def handle_offline(self, s: dict) -> None:
        db = self.bot.db
        login = s["login"].lower()
        state = db.tw_get(login)
        if not state or not state["live"]:
            return
        db.tw_set(login, live=0, ended_at=int(time.time()))
        log.info("Стрим закончился: %s", login)
        if not self.cfg.get("edit_on_end", True) or not state["message_id"]:
            return
        user = await self.get_user(login)
        embed, view = self.build_offline(s, state, user)
        try:
            await self.bot.notifier.edit(
                state["channel_id"], state["message_id"], bool(state["via_webhook"]), embed=embed, view=view
            )
        except discord.HTTPException as e:
            log.warning("Не смог отредактировать уведомление о конце стрима: %s", e)

    # ------------------------------------------------------- сообщения --
    def build_live(self, s: dict, stream: dict, user: dict, with_ping: bool = True):
        login = s["login"].lower()
        name = stream.get("user_name") or user.get("display_name") or login
        url = f"https://www.twitch.tv/{login}"
        game = stream.get("game_name") or "Просто общение"
        content = render(
            s.get("message") or "{ping} **{name}** в эфире!",
            ping=ping_text(s.get("ping")) if with_ping else "",
            name=name,
            title=stream.get("title", ""),
            game=game,
            url=url,
        )
        embed = discord.Embed(
            title=shorten(stream.get("title") or "Стрим", 256),
            url=url,
            color=TWITCH_PURPLE,
            timestamp=parse_iso(stream.get("started_at")) or discord.utils.utcnow(),
        )
        embed.set_author(name=f"{name} в эфире на Twitch", url=url, icon_url=user.get("profile_image_url") or None)
        embed.add_field(name="🎮 Игра", value=game, inline=True)
        embed.add_field(name="👀 Зрители", value=fmt_number(stream.get("viewer_count", 0)), inline=True)
        thumb = (stream.get("thumbnail_url") or "").replace("{width}", "1280").replace("{height}", "720")
        if thumb:
            embed.set_image(url=f"{thumb}?t={int(time.time())}")  # чтоб дискорд не кешировал старое превью
        embed.set_footer(text="Twitch • Стрим начался")
        view = link_view(("Залететь на стрим", url, "🟣"))
        return content or None, embed, view

    def build_offline(self, s: dict, state, user: dict):
        login = s["login"].lower()
        name = user.get("display_name") or login
        started = parse_iso(state["started_at"])
        duration = fmt_duration(time.time() - started.timestamp()) if started else "?"
        videos_url = f"https://www.twitch.tv/{login}/videos"
        embed = discord.Embed(
            title=shorten(state["title"] or "Стрим", 256),
            url=videos_url,
            description=f"⚫ Стрим закончился. Длился **{duration}**.\nЗапись — по кнопке ниже (если включены записи).",
            color=OFFLINE_GREY,
            timestamp=discord.utils.utcnow(),
        )
        embed.set_author(name=f"{name} был в эфире", url=videos_url, icon_url=user.get("profile_image_url") or None)
        if state["game"]:
            embed.add_field(name="🎮 Игра", value=state["game"], inline=True)
        if user.get("offline_image_url"):
            embed.set_image(url=user["offline_image_url"])
        embed.set_footer(text="Twitch • Стрим окончен")
        view = link_view(("Записи стримов", videos_url, "📼"), ("Канал", f"https://www.twitch.tv/{login}", "🟣"))
        return embed, view

    # ------------------------------------------------------- команды --
    @tw_admin.command(name="test", description="Превью уведомления о стриме")
    async def test(self, interaction: discord.Interaction):
        if not self.api:
            return await interaction.response.send_message(
                "Твич не настроен: нужны TWITCH_CLIENT_ID/SECRET в .env и ник в config.toml", ephemeral=True
            )
        await interaction.response.defer(ephemeral=True, thinking=True)
        s = self.streamers[0]
        login = s["login"].lower()
        live = await self.api.streams([login])
        user = await self.get_user(login)
        if not user:
            return await interaction.followup.send(f"Твич не знает юзера `{login}` — проверь ник.", ephemeral=True)
        stream = live.get(login) or {
            "id": "test",
            "user_name": user.get("display_name", login),
            "title": "Тестовый стрим — так будет выглядеть уведомление",
            "game_name": "Rust",
            "viewer_count": 69,
            "started_at": discord.utils.utcnow().isoformat(),
            "thumbnail_url": user.get("offline_image_url") or "",
        }
        content, embed, view = self.build_live(s, stream, user)
        kwargs = {"ephemeral": True, "embed": embed}
        if view:
            kwargs["view"] = view
        await interaction.followup.send(f"**Превью** (пинг тут не сработает):\n{content or ''}", **kwargs)

    @tw_admin.command(name="status", description="Кто сейчас в эфире")
    async def status(self, interaction: discord.Interaction):
        if not self.api:
            return await interaction.response.send_message("Твич не настроен.", ephemeral=True)
        await interaction.response.defer(ephemeral=True, thinking=True)
        live = await self.api.streams([s["login"] for s in self.streamers])
        lines = []
        for s in self.streamers:
            login = s["login"].lower()
            if login in live:
                st = live[login]
                lines.append(f"🔴 **{st['user_name']}** — {st.get('game_name')} · {fmt_number(st.get('viewer_count', 0))} зрителей")
            else:
                lines.append(f"⚫ **{login}** — оффлайн")
        await interaction.followup.send("\n".join(lines), ephemeral=True)


async def setup(bot):
    await bot.add_cog(Twitch(bot))

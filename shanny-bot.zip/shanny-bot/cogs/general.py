"""Общие команды: /help, /links, /ping."""
import discord
from discord import app_commands
from discord.ext import commands

from utils.helpers import social_links_view


class General(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="links", description="Все соцсети ShannY")
    async def links(self, interaction: discord.Interaction):
        links = self.bot.cfg.get("links", {})
        view = social_links_view(links)
        if view is None:
            return await interaction.response.send_message("Ссылки пока не добавлены.", ephemeral=True)
        embed = discord.Embed(title="🔗 Где меня найти", description="Подписывайся, чтобы ничего не пропустить 👇", color=self.bot.color)
        await interaction.response.send_message(embed=embed, view=view)

    @app_commands.command(name="ping", description="Проверить, живой ли бот")
    async def ping(self, interaction: discord.Interaction):
        await interaction.response.send_message(f"Понг! 🏓 {round(self.bot.latency * 1000)} мс", ephemeral=True)

    @app_commands.command(name="help", description="Что умеет бот")
    async def help(self, interaction: discord.Interaction):
        cfg = self.bot.cfg
        embed = discord.Embed(title="🤖 Команды бота", color=self.bot.color)
        everyone = ["`/links` — соцсети", "`/ping` — проверить бота"]
        if cfg.get("youtube", {}).get("enabled"):
            everyone.append("`/last` — последний ролик")
        if cfg.get("ideas", {}).get("enabled"):
            everyone.append("`/idea` — предложить идею для ролика")
        embed.add_field(name="Для всех", value="\n".join(everyone), inline=False)

        admin = [
            "`/webhook send` — сообщение через вебхук (форма)",
            "`/webhook json` — сообщение из JSON (discohook.org)",
            "`/webhook edit` — отредактировать сообщение бота",
            "`/clear` · `/slowmode` — модерация",
        ]
        if cfg.get("youtube", {}).get("enabled"):
            admin.append("`/youtube test` · `/youtube check` · `/youtube channels`")
        if cfg.get("twitch", {}).get("enabled"):
            admin.append("`/twitch test` · `/twitch status`")
        if cfg.get("roles", {}).get("enabled"):
            admin.append("`/rolepanel` — панель ролей-уведомлений")
        if cfg.get("ideas", {}).get("enabled"):
            admin.append("`/ideastatus` — статус идеи")
        embed.add_field(name="Для админов", value="\n".join(admin), inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot):
    await bot.add_cog(General(bot))

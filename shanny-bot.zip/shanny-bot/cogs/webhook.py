"""
Отправка сообщений через вебхук:
  /webhook send  — форма: текст + карточка (embed), от любого имени и с любой авой
  /webhook json  — закинуть JSON из discohook.org (собираешь красиво там, постишь ботом)
  /webhook edit  — отредактировать сообщение, которое бот/его вебхук уже отправил
"""
import json
import logging

import discord
from discord import app_commands
from discord.ext import commands

from utils.helpers import ALLOW_PINGS
from utils.text import is_webhook_url, parse_color, parse_message_link

log = logging.getLogger("webhook")


class MessageModal(discord.ui.Modal):
    def __init__(self, *, title: str, on_done, defaults: dict | None = None):
        super().__init__(title=title[:45], timeout=900)
        d = defaults or {}
        self.on_done = on_done
        self.f_content = discord.ui.TextInput(
            label="Текст сообщения",
            style=discord.TextStyle.paragraph,
            required=False,
            max_length=2000,
            default=d.get("content") or None,
            placeholder="Можно с пингами: @everyone, <@&ID_роли>, **жирный**, ссылки…",
        )
        self.f_title = discord.ui.TextInput(
            label="Заголовок карточки (embed)", required=False, max_length=256, default=d.get("title") or None
        )
        self.f_desc = discord.ui.TextInput(
            label="Текст карточки",
            style=discord.TextStyle.paragraph,
            required=False,
            max_length=4000,
            default=d.get("description") or None,
        )
        self.f_image = discord.ui.TextInput(
            label="Картинка в карточке (ссылка)",
            required=False,
            max_length=1000,
            default=d.get("image") or None,
            placeholder="https://….png",
        )
        self.f_color = discord.ui.TextInput(
            label="Цвет карточки", required=False, max_length=10, default=d.get("color") or None, placeholder="#9B59B6"
        )
        for item in (self.f_content, self.f_title, self.f_desc, self.f_image, self.f_color):
            self.add_item(item)

    def values(self) -> dict:
        return {
            "content": self.f_content.value.strip(),
            "title": self.f_title.value.strip(),
            "description": self.f_desc.value.strip(),
            "image": self.f_image.value.strip(),
            "color": self.f_color.value.strip(),
        }

    async def on_submit(self, interaction: discord.Interaction):
        await self.on_done(interaction, self.values())

    async def on_error(self, interaction: discord.Interaction, error: Exception):
        log.exception("Ошибка в форме вебхука", exc_info=error)
        msg = f"Не получилось: `{error}`"
        if interaction.response.is_done():
            await interaction.followup.send(msg, ephemeral=True)
        else:
            await interaction.response.send_message(msg, ephemeral=True)


def build_embed(v: dict, default_color: int) -> discord.Embed | None:
    if not (v["title"] or v["description"] or v["image"]):
        return None
    embed = discord.Embed(
        title=v["title"] or None,
        description=v["description"] or None,
        color=parse_color(v["color"], default_color),
    )
    if v["image"]:
        if not v["image"].startswith(("http://", "https://")):
            raise ValueError("ссылка на картинку должна начинаться с https://")
        embed.set_image(url=v["image"])
    return embed


def extract_messages(data) -> list[dict]:
    """Понимает форматы discohook.org (share/backup) и обычный JSON вебхука."""
    if isinstance(data, list):
        items = data
    elif isinstance(data, dict) and isinstance(data.get("messages"), list):
        items = [m.get("data", m) for m in data["messages"] if isinstance(m, dict)]
    elif isinstance(data, dict) and isinstance(data.get("backups"), list):
        items = [m.get("data", m) for b in data["backups"] for m in b.get("messages", []) if isinstance(m, dict)]
    else:
        items = [data]
    return [i for i in items if isinstance(i, dict) and (i.get("content") or i.get("embeds"))]


class Webhooks(commands.Cog):
    wh = app_commands.Group(
        name="webhook",
        description="Сообщения через вебхук",
        default_permissions=discord.Permissions(manage_webhooks=True),
        guild_only=True,
    )

    def __init__(self, bot):
        self.bot = bot

    @property
    def defaults(self) -> dict:
        return self.bot.cfg.get("notify", {})

    async def resolve_target(self, interaction, channel, url) -> discord.Webhook:
        if url:
            if not is_webhook_url(url):
                raise ValueError("это не похоже на ссылку вебхука дискорда")
            return discord.Webhook.from_url(url.strip(), session=self.bot.http_session)
        target = channel or interaction.channel
        return await self.bot.notifier.get_webhook(target)

    async def _send(self, hook: discord.Webhook, *, content, embeds, name, avatar):
        kwargs = {"allowed_mentions": ALLOW_PINGS, "wait": True}
        if content:
            kwargs["content"] = content[:2000]
        if embeds:
            kwargs["embeds"] = embeds[:10]
        name = name or self.defaults.get("webhook_name")
        avatar = avatar or self.defaults.get("webhook_avatar_url")
        if name:
            kwargs["username"] = name[:80]
        if avatar:
            kwargs["avatar_url"] = avatar
        return await hook.send(**kwargs)

    # -------------------------------------------------------------- send --
    @wh.command(name="send", description="Отправить сообщение через вебхук (откроется форма)")
    @app_commands.describe(
        channel="Канал на этом сервере (по умолчанию — текущий)",
        url="Или ссылка на любой вебхук (например, другого сервера)",
        name="Имя отправителя (по умолчанию из конфига)",
        avatar="Ссылка на аватарку отправителя",
    )
    async def send(
        self,
        interaction: discord.Interaction,
        channel: discord.TextChannel | None = None,
        url: str | None = None,
        name: str | None = None,
        avatar: str | None = None,
    ):
        async def done(inter: discord.Interaction, v: dict):
            embed = build_embed(v, self.bot.color)
            if not v["content"] and embed is None:
                return await inter.response.send_message("Пустое сообщение не отправить 🙃", ephemeral=True)
            await inter.response.defer(ephemeral=True, thinking=True)
            hook = await self.resolve_target(inter, channel, url)
            msg = await self._send(hook, content=v["content"], embeds=[embed] if embed else [], name=name, avatar=avatar)
            await inter.followup.send(f"Отправил ✅ {msg.jump_url}", ephemeral=True)

        await interaction.response.send_modal(MessageModal(title="Сообщение через вебхук", on_done=done))

    # -------------------------------------------------------------- json --
    @wh.command(name="json", description="Отправить сообщение из JSON (например, из discohook.org)")
    @app_commands.describe(
        file="JSON-файл (discohook: «Backups» → Export, или просто JSON сообщения)",
        channel="Канал (по умолчанию — текущий)",
        url="Или ссылка на любой вебхук",
        name="Имя отправителя (перебьёт то, что в JSON)",
        avatar="Ссылка на аватарку (перебьёт то, что в JSON)",
    )
    async def from_json(
        self,
        interaction: discord.Interaction,
        file: discord.Attachment,
        channel: discord.TextChannel | None = None,
        url: str | None = None,
        name: str | None = None,
        avatar: str | None = None,
    ):
        await interaction.response.defer(ephemeral=True, thinking=True)
        if file.size > 1_000_000:
            return await interaction.followup.send("Файл слишком жирный (макс 1 МБ).", ephemeral=True)
        try:
            data = json.loads((await file.read()).decode("utf-8-sig"))
        except (UnicodeDecodeError, json.JSONDecodeError) as e:
            return await interaction.followup.send(f"Кривой JSON: `{e}`", ephemeral=True)

        messages = extract_messages(data)
        if not messages:
            return await interaction.followup.send("В JSON не нашёл ни текста, ни embed'ов.", ephemeral=True)

        hook = await self.resolve_target(interaction, channel, url)
        links = []
        for m in messages[:10]:
            embeds = [discord.Embed.from_dict(e) for e in (m.get("embeds") or []) if isinstance(e, dict)]
            msg = await self._send(
                hook,
                content=m.get("content"),
                embeds=embeds,
                name=name or m.get("username"),
                avatar=avatar or m.get("avatar_url"),
            )
            links.append(msg.jump_url)
        await interaction.followup.send(f"Отправил {len(links)} сообщ. ✅\n" + "\n".join(links), ephemeral=True)

    # -------------------------------------------------------------- edit --
    @wh.command(name="edit", description="Отредактировать сообщение бота или его вебхука")
    @app_commands.describe(link="Ссылка на сообщение (ПКМ по сообщению → Копировать ссылку)")
    async def edit(self, interaction: discord.Interaction, link: str):
        parsed = parse_message_link(link)
        if not parsed:
            return await interaction.response.send_message("Это не ссылка на сообщение.", ephemeral=True)
        channel_id, message_id = parsed
        channel = await self.bot.notifier.get_channel(channel_id)
        msg = await channel.fetch_message(message_id)

        if msg.webhook_id:
            hook = next((h for h in await channel.webhooks() if h.id == msg.webhook_id and h.token), None)
            if hook is None:
                return await interaction.response.send_message(
                    "Это сообщение от чужого вебхука — его может редачить только тот, кто его создал.", ephemeral=True
                )

            async def apply(**kw):
                await hook.edit_message(msg.id, **kw)

        elif msg.author.id == self.bot.user.id:

            async def apply(**kw):
                await msg.edit(**kw)

        else:
            return await interaction.response.send_message(
                "Могу редактировать только сообщения самого бота или его вебхуков.", ephemeral=True
            )

        first = msg.embeds[0] if msg.embeds else None
        defaults = {
            "content": (msg.content or "")[:2000],
            "title": ((first.title if first else "") or "")[:256],
            "description": ((first.description if first else "") or "")[:4000],
            "image": ((first.image.url if first and first.image else "") or "")[:1000],
            "color": f"#{first.color.value:06X}" if first and first.color else "",
        }

        async def done(inter: discord.Interaction, v: dict):
            embed = build_embed(v, self.bot.color)
            rest = msg.embeds[1:]
            embeds = ([embed] if embed else []) + rest
            if not v["content"] and not embeds:
                return await inter.response.send_message("Нельзя сделать сообщение пустым.", ephemeral=True)
            await inter.response.defer(ephemeral=True, thinking=True)
            await apply(content=v["content"] or None, embeds=embeds, allowed_mentions=ALLOW_PINGS)
            await inter.followup.send(f"Отредактировал ✅ {msg.jump_url}", ephemeral=True)

        await interaction.response.send_modal(MessageModal(title="Редактировать сообщение", on_done=done, defaults=defaults))


async def setup(bot):
    await bot.add_cog(Webhooks(bot))

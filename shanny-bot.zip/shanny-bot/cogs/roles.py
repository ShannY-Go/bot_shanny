"""Роли по кнопкам: люди сами подписываются на пинги (ролики / шортсы / стримы)."""
import logging

import discord
from discord import app_commands
from discord.ext import commands

from utils.helpers import BUTTON_STYLES
from utils.text import is_set

log = logging.getLogger("roles")
PREFIX = "rr:"


class Roles(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.cfg: dict = bot.cfg.get("roles", {})

    def build_view(self) -> discord.ui.View | None:
        view = discord.ui.View(timeout=None)
        for b in self.cfg.get("buttons", [])[:25]:
            if not is_set(b.get("role_id")):
                continue
            view.add_item(
                discord.ui.Button(
                    label=(b.get("label") or "Роль")[:80],
                    emoji=b.get("emoji") or None,
                    style=BUTTON_STYLES.get(str(b.get("style", "grey")).lower(), discord.ButtonStyle.secondary),
                    custom_id=f"{PREFIX}{int(b['role_id'])}",
                )
            )
        return view if view.children else None

    @app_commands.command(name="rolepanel", description="Отправить панель с кнопками ролей-уведомлений")
    @app_commands.describe(channel="Куда отправить (по умолчанию — сюда)")
    @app_commands.default_permissions(manage_roles=True)
    @app_commands.guild_only()
    async def rolepanel(self, interaction: discord.Interaction, channel: discord.TextChannel | None = None):
        view = self.build_view()
        if view is None:
            return await interaction.response.send_message(
                "В config.toml в [[roles.buttons]] не вписаны role_id.", ephemeral=True
            )
        embed = discord.Embed(
            title=self.cfg.get("panel_title", "🔔 Уведомления"),
            description=self.cfg.get("panel_text", "Жми кнопки, чтобы взять роль."),
            color=self.bot.color,
        )
        lines = []
        for b in self.cfg.get("buttons", []):
            if is_set(b.get("role_id")):
                lines.append(f"{b.get('emoji', '•')} **{b.get('label', 'Роль')}** — <@&{int(b['role_id'])}>")
        if lines:
            embed.add_field(name="​", value="\n".join(lines), inline=False)
        target = channel or interaction.channel
        await target.send(embed=embed, view=view)
        view.stop()  # клики обрабатывает on_interaction ниже — работает и после перезапуска
        await interaction.response.send_message(f"Панель отправлена в {target.mention} ✅", ephemeral=True)

    @commands.Cog.listener()
    async def on_interaction(self, interaction: discord.Interaction):
        if interaction.type is not discord.InteractionType.component:
            return
        custom_id = (interaction.data or {}).get("custom_id", "")
        if not custom_id.startswith(PREFIX) or interaction.guild is None:
            return
        try:
            role = interaction.guild.get_role(int(custom_id[len(PREFIX):]))
        except ValueError:
            return
        if role is None:
            return await interaction.response.send_message("Этой роли больше нет 🤷", ephemeral=True)

        member = interaction.user
        if not isinstance(member, discord.Member):
            member = await interaction.guild.fetch_member(interaction.user.id)

        me = interaction.guild.me
        if role >= me.top_role:
            return await interaction.response.send_message(
                "Не могу выдать эту роль — она выше роли бота. Админ, подними роль бота в настройках сервера.",
                ephemeral=True,
            )
        try:
            if role in member.roles:
                await member.remove_roles(role, reason="Роль по кнопке")
                text = f"Снял роль {role.mention} — больше не будешь получать эти пинги."
            else:
                await member.add_roles(role, reason="Роль по кнопке")
                text = f"Выдал роль {role.mention} 🔔"
        except discord.Forbidden:
            text = "У бота нет права «Управлять ролями»."
        await interaction.response.send_message(text, ephemeral=True)


async def setup(bot):
    await bot.add_cog(Roles(bot))

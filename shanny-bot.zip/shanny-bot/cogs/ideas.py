"""
Идеи для роликов от зрителей:
  /idea <текст>  — карточка с идеей в канале идей + бот сам ставит реакции «да» / «нет»
  /ideastatus    — (админ) поменять статус идеи: принято / снято / отклонено
"""
import logging
import time

import discord
from discord import app_commands
from discord.ext import commands

from utils.helpers import NO_PINGS
from utils.text import is_set, parse_message_link

log = logging.getLogger("ideas")

STATUSES = {
    "review": ("🕐 На рассмотрении", 0xF1C40F),
    "accepted": ("✅ Взял в работу", 0x2ECC71),
    "done": ("🎬 Снято! Ролик вышел", 0x9B59B6),
    "rejected": ("❌ Не в этот раз", 0xE74C3C),
}


class Ideas(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.cfg: dict = bot.cfg.get("ideas", {})
        self.cooldowns: dict[int, float] = {}

    def _vote_emoji(self, key: str, fallback: str):
        """Своя эмодзи сервера по ID из конфига; если не задана — обычная."""
        emoji_id = self.cfg.get(key)
        if not is_set(emoji_id):
            return fallback
        return self.bot.get_emoji(int(emoji_id)) or discord.PartialEmoji(name="vote", id=int(emoji_id))

    @app_commands.command(name="idea", description="Предложить идею для ролика")
    @app_commands.describe(idea="В чём суть твоей идеи?")
    @app_commands.guild_only()
    async def idea(self, interaction: discord.Interaction, idea: app_commands.Range[str, 3, 4000]):
        if not is_set(self.cfg.get("channel_id")):
            return await interaction.response.send_message("Канал для идей не настроен.", ephemeral=True)
        cd = float(self.cfg.get("cooldown_minutes", 0)) * 60
        left = self.cooldowns.get(interaction.user.id, 0) + cd - time.time()
        if left > 0:
            return await interaction.response.send_message(
                f"Погоди ещё {int(left // 60) + 1} мин перед следующей идеей 🙏", ephemeral=True
            )
        # Реакции ставятся не мгновенно — отвечаем дискорду сразу, чтобы команда не «протухла»
        await interaction.response.defer(ephemeral=True)
        await self.publish(interaction, idea.strip())

    async def publish(self, interaction: discord.Interaction, text: str):
        channel_id = int(self.cfg["channel_id"])
        channel = self.bot.get_channel(channel_id)
        if channel is None:
            try:
                channel = await self.bot.fetch_channel(channel_id)
            except discord.HTTPException:
                return await interaction.followup.send("Канал для идей не найден — скажи админу.", ephemeral=True)

        label, color = STATUSES["review"]
        embed = discord.Embed(title="💡 Новая идея", description=text, color=color, timestamp=discord.utils.utcnow())
        embed.set_author(name=interaction.user.display_name, icon_url=interaction.user.display_avatar.url)
        embed.add_field(name="Статус", value=label, inline=False)
        embed.set_footer(text=f"ID автора: {interaction.user.id}")
        try:
            msg = await channel.send(embed=embed, allowed_mentions=NO_PINGS)
        except discord.Forbidden:
            return await interaction.followup.send(
                "У бота нет прав писать в канал идей — скажи админу.", ephemeral=True
            )

        # Сначала «да», потом «нет». Если своя эмодзи недоступна — ставим обычные 👍/👎
        for key, fallback in (("yes_emoji_id", "👍"), ("no_emoji_id", "👎")):
            try:
                await msg.add_reaction(self._vote_emoji(key, fallback))
            except discord.HTTPException as e:
                log.warning("Не смог поставить эмодзи %s (%s) — ставлю %s", self.cfg.get(key), e, fallback)
                try:
                    await msg.add_reaction(fallback)
                except discord.HTTPException:
                    pass

        if self.cfg.get("create_thread", False):
            try:
                await msg.create_thread(name=text[:95] or "Обсуждение")
            except discord.HTTPException:
                pass
        self.cooldowns[interaction.user.id] = time.time()
        await interaction.followup.send(f"Идея улетела в {channel.mention} 🚀 Спасибо!", ephemeral=True)

    @app_commands.command(name="ideastatus", description="Поменять статус идеи")
    @app_commands.describe(link="Ссылка на сообщение с идеей", status="Новый статус", comment="Комментарий (необязательно)")
    @app_commands.choices(
        status=[app_commands.Choice(name=label, value=key) for key, (label, _) in STATUSES.items()]
    )
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.guild_only()
    async def ideastatus(
        self,
        interaction: discord.Interaction,
        link: str,
        status: app_commands.Choice[str],
        comment: str | None = None,
    ):
        parsed = parse_message_link(link)
        if not parsed:
            return await interaction.response.send_message("Это не ссылка на сообщение.", ephemeral=True)
        channel = self.bot.get_channel(parsed[0]) or await self.bot.fetch_channel(parsed[0])
        msg = await channel.fetch_message(parsed[1])
        if msg.author.id != self.bot.user.id or not msg.embeds:
            return await interaction.response.send_message("Это не карточка идеи от бота.", ephemeral=True)

        label, color = STATUSES[status.value]
        embed = msg.embeds[0].copy()
        embed.color = color
        embed.clear_fields()
        embed.add_field(name="Статус", value=label, inline=False)
        if comment:
            embed.add_field(name=f"Комментарий от {interaction.user.display_name}", value=comment[:1024], inline=False)
        await msg.edit(embed=embed)
        await interaction.response.send_message(f"Статус обновлён: {label}", ephemeral=True)


async def setup(bot):
    await bot.add_cog(Ideas(bot))

"""Приветствие новичков, автороль и (по желанию) сообщение, когда кто-то ливнул."""
import logging

import discord
from discord.ext import commands

from utils.helpers import NO_PINGS, social_links_view
from utils.text import is_set, render

log = logging.getLogger("welcome")


class Welcome(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.cfg: dict = bot.cfg.get("welcome", {})

    def _vars(self, member: discord.Member) -> dict:
        return {
            "mention": member.mention,
            "name": member.display_name,
            "server": member.guild.name,
            "count": member.guild.member_count or len(member.guild.members),
        }

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if member.bot:
            return
        if is_set(self.cfg.get("auto_role_id")):
            role = member.guild.get_role(int(self.cfg["auto_role_id"]))
            if role:
                try:
                    await member.add_roles(role, reason="Автороль новичку")
                except discord.Forbidden:
                    log.warning("Не могу выдать автороль — роль бота ниже или нет права «Управлять ролями»")

        channel_id = self.cfg.get("channel_id")
        if not is_set(channel_id):
            return
        channel = member.guild.get_channel(int(channel_id))
        if channel is None:
            return
        v = self._vars(member)
        embed = discord.Embed(
            title=render(self.cfg.get("title", "Добро пожаловать!"), **v),
            description=render(self.cfg.get("message", "Здарова, {mention}!"), **v),
            color=self.bot.color,
        )
        embed.set_thumbnail(url=member.display_avatar.url)
        embed.set_footer(text=f"Участник #{v['count']}")
        kwargs = {
            "content": member.mention,
            "embed": embed,
            "allowed_mentions": discord.AllowedMentions(users=True, roles=False, everyone=False),
        }
        if self.cfg.get("show_links", True):
            view = social_links_view(self.bot.cfg.get("links", {}))
            if view:
                kwargs["view"] = view
        try:
            await channel.send(**kwargs)
        except discord.HTTPException as e:
            log.warning("Не смог отправить приветствие: %s", e)

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        if member.bot or not self.cfg.get("leave_enabled"):
            return
        channel_id = self.cfg.get("channel_id")
        if not is_set(channel_id):
            return
        channel = member.guild.get_channel(int(channel_id))
        if channel is None:
            return
        try:
            await channel.send(render(self.cfg.get("leave_message", "**{name}** ливнул."), **self._vars(member)),
                               allowed_mentions=NO_PINGS)
        except discord.HTTPException:
            pass


async def setup(bot):
    await bot.add_cog(Welcome(bot))

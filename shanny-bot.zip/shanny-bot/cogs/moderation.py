"""Базовая модерация. Для фильтра мата/спама лучше включить встроенный AutoMod дискорда."""
import discord
from discord import app_commands
from discord.ext import commands


class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="clear", description="Удалить последние сообщения в канале")
    @app_commands.describe(amount="Сколько (1–100)", user="Только сообщения этого человека")
    @app_commands.default_permissions(manage_messages=True)
    @app_commands.guild_only()
    async def clear(
        self,
        interaction: discord.Interaction,
        amount: app_commands.Range[int, 1, 100],
        user: discord.Member | None = None,
    ):
        await interaction.response.defer(ephemeral=True, thinking=True)
        check = (lambda m: m.author.id == user.id) if user else (lambda m: True)
        deleted = await interaction.channel.purge(limit=amount, check=check)
        await interaction.followup.send(f"Удалил {len(deleted)} сообщ. 🧹", ephemeral=True)

    @app_commands.command(name="slowmode", description="Медленный режим в канале")
    @app_commands.describe(seconds="Задержка в секундах (0 = выключить, макс 21600)")
    @app_commands.default_permissions(manage_channels=True)
    @app_commands.guild_only()
    async def slowmode(self, interaction: discord.Interaction, seconds: app_commands.Range[int, 0, 21600]):
        await interaction.channel.edit(slowmode_delay=seconds)
        text = "Медленный режим выключен." if seconds == 0 else f"Медленный режим: {seconds} сек 🐢"
        await interaction.response.send_message(text, ephemeral=True)


async def setup(bot):
    await bot.add_cog(Moderation(bot))

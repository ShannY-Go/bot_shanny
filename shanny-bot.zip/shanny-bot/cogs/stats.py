"""
Счётчики в названиях голосовых каналов:
  • участники сервера Discord
  • подписчики на YouTube
  • подписчики (фолловеры) на Twitch
Каждый счётчик обновляется независимо: если упал один, остальные всё равно обновятся.
"""
import logging

import discord
from discord.ext import commands, tasks

from utils import yt
from utils.text import fmt_number, is_set, render
from utils.twitch_api import TwitchAPI, decapi_follower_count

log = logging.getLogger("stats")


class Stats(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.cfg: dict = bot.cfg.get("stats", {})
        self.api_key = bot.env.get("YOUTUBE_API_KEY") or None
        self.twitch: TwitchAPI | None = None
        self._yt_channel_id: str | None = None
        self._warned: set[str] = set()  # чтобы не спамить одним и тем же предупреждением

    def _warn_once(self, key: str, text: str, *args) -> None:
        if key not in self._warned:
            self._warned.add(key)
            log.warning(text, *args)

    async def cog_load(self):
        cid, secret = self.bot.env.get("TWITCH_CLIENT_ID"), self.bot.env.get("TWITCH_CLIENT_SECRET")
        if cid and secret:
            self.twitch = TwitchAPI(self.bot.http_session, cid, secret)
        # Дискорд разрешает переименовывать канал 2 раза за 10 минут — чаще нет смысла
        minutes = max(10.0, float(self.cfg.get("update_interval_minutes", 15)))
        self.update_loop.change_interval(minutes=minutes)
        self.update_loop.start()

    async def cog_unload(self):
        self.update_loop.cancel()

    @tasks.loop(minutes=15)
    async def update_loop(self):
        for name, job in (
            ("участники", self.update_members),
            ("YouTube", self.update_youtube),
            ("Twitch", self.update_twitch),
        ):
            try:
                await job()
            except Exception:
                log.exception("Не удалось обновить счётчик «%s»", name)

    @update_loop.before_loop
    async def _before(self):
        await self.bot.wait_until_ready()

    # ------------------------------------------------------------ общее --
    def _channel(self, channel_id):
        channel = self.bot.get_channel(int(channel_id))
        if channel is None:
            self._warn_once(
                f"nochan:{channel_id}",
                "Не вижу канал %s: бот не на сервере, нет доступа к каналу или неверный ID",
                channel_id,
            )
        return channel

    async def _rename(self, channel, template: str, count: int) -> None:
        name = render(template, count=fmt_number(count))[:100]
        if channel.name == name:
            return  # не изменилось — не трогаем, экономим лимит дискорда
        try:
            await channel.edit(name=name, reason="Обновление счётчика")
            log.info("Счётчик обновлён: %s", name)
        except discord.Forbidden:
            self._warn_once(
                f"forbidden:{channel.id}",
                "Нет прав переименовать канал %s: дай боту право «Управление каналом» на этом канале",
                channel.id,
            )
        except discord.HTTPException as e:
            log.warning("Не смог переименовать канал %s: %s", channel.id, e)

    # --------------------------------------------------------- участники --
    async def update_members(self) -> None:
        channel_id = self.cfg.get("members_channel_id")
        if not is_set(channel_id):
            return
        channel = self._channel(channel_id)
        if channel is None:
            return
        guild = channel.guild
        # Боты в счёт не идут, если список участников загружен целиком
        count = sum(1 for m in guild.members if not m.bot) if guild.chunked else guild.member_count
        await self._rename(channel, self.cfg.get("members_format", "👥 Участников: {count}"), count)

    # ----------------------------------------------------------- YouTube --
    def _first_youtube_channel(self) -> str:
        channels = self.bot.cfg.get("youtube", {}).get("channels", [])
        return (channels[0].get("channel_id") or channels[0].get("handle") or "") if channels else ""

    async def update_youtube(self) -> None:
        channel_id = self.cfg.get("subs_channel_id")
        if not is_set(channel_id):
            return
        if not self.api_key:
            return self._warn_once("noyt", "Счётчик YouTube: нужен YOUTUBE_API_KEY в .env")
        channel = self._channel(channel_id)
        if channel is None:
            return
        if not self._yt_channel_id:
            source = self.cfg.get("subs_youtube") or self._first_youtube_channel()
            if not source:
                return self._warn_once("noytsrc", "Счётчик YouTube: впиши subs_youtube в [stats]")
            self._yt_channel_id, _, _ = await yt.resolve_channel(self.bot.http_session, source, self.api_key)
        subs = await yt.api_subscribers(self.bot.http_session, self._yt_channel_id, self.api_key)
        if subs is None:
            return self._warn_once("ythidden", "YouTube не отдал число подписчиков (скрыто на канале?)")
        await self._rename(channel, self.cfg.get("subs_format", "▶️ Подписчиков: {count}"), subs)

    # ------------------------------------------------------------ Twitch --
    def _twitch_login(self) -> str:
        login = str(self.cfg.get("twitch_login") or "").strip().lstrip("@")
        if not login:  # не задан — берём ник из [[twitch.streamers]]
            streamers = self.bot.cfg.get("twitch", {}).get("streamers", [])
            login = str(streamers[0].get("login", "")).strip() if streamers else ""
        return "" if "впиши" in login else login

    async def update_twitch(self) -> None:
        channel_id = self.cfg.get("twitch_channel_id")
        if not is_set(channel_id):
            return
        login = self._twitch_login()
        if not login:
            return self._warn_once("notwlogin", "Счётчик Twitch: впиши свой ник в twitch_login в разделе [stats]")
        channel = self._channel(channel_id)
        if channel is None:
            return

        count: int | None = None
        if self.twitch:
            try:
                count = await self.twitch.follower_count(login)
            except Exception as e:
                self._warn_once("twapi", "Twitch API не отдал фолловеров (%s) — пробую запасной способ", e)
        if count is None:
            try:
                count = await decapi_follower_count(self.bot.http_session, login)
            except Exception as e:
                log.warning("Запасной способ (decapi.me) тоже не сработал: %s", e)
        if count is None:
            return
        await self._rename(channel, self.cfg.get("twitch_format", "🟣 Подписчиков: {count}"), count)


async def setup(bot):
    await bot.add_cog(Stats(bot))

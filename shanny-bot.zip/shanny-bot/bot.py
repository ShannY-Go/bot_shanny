"""
ShannY Bot — бот для Discord-сервера ютубера.
Запуск:  python bot.py   (или start.bat на винде)
"""
import asyncio
import logging
import os
import sys
import tomllib
from logging.handlers import RotatingFileHandler
from pathlib import Path

import aiohttp
import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

from utils.db import DB
from utils.notify import Notifier
from utils.text import is_set, parse_color

ROOT = Path(__file__).resolve().parent
USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/130.0 Safari/537.36"
)
log = logging.getLogger("bot")


def fatal(message: str) -> None:
    """Ошибка настройки: перезапуск не поможет, start.bat остановится и подождёт."""
    print(message, file=sys.stderr)
    sys.exit(2)


def setup_logging() -> None:
    # Чтобы эмодзи и русский не ломали консоль на винде
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    (ROOT / "logs").mkdir(exist_ok=True)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s", "%Y-%m-%d %H:%M:%S")
    console = logging.StreamHandler(sys.stdout)
    console.setFormatter(fmt)
    file = RotatingFileHandler(ROOT / "logs" / "bot.log", maxBytes=2_000_000, backupCount=3, encoding="utf-8")
    file.setFormatter(fmt)
    logging.basicConfig(level=logging.INFO, handlers=[console, file])
    logging.getLogger("discord.http").setLevel(logging.WARNING)


def load_config() -> dict:
    path = ROOT / "config.toml"
    if not path.exists():
        fatal("❌ Нет файла config.toml рядом с bot.py")
    try:
        # utf-8-sig — на случай, если блокнот добавил BOM
        return tomllib.loads(path.read_bytes().decode("utf-8-sig"))
    except tomllib.TOMLDecodeError as e:
        fatal(
            f"❌ Ошибка в config.toml: {e}\n"
            "Частые причины: текст без кавычек; текст в несколько строк в обычных кавычках "
            '(для этого нужны тройные: """много строк""").'
        )


def extensions(cfg: dict) -> list[tuple[str, bool]]:
    on = lambda section: bool(cfg.get(section, {}).get("enabled", False))  # noqa: E731
    return [
        ("cogs.general", True),
        ("cogs.webhook", True),
        ("cogs.moderation", True),
        ("cogs.youtube", on("youtube")),
        ("cogs.twitch", on("twitch")),
        ("cogs.roles", on("roles")),
        ("cogs.welcome", on("welcome")),
        ("cogs.ideas", on("ideas")),
        ("cogs.stats", on("stats")),
    ]


BOT_PERMISSIONS = discord.Permissions(
    view_channel=True,
    send_messages=True,
    send_messages_in_threads=True,
    embed_links=True,
    attach_files=True,
    read_message_history=True,
    mention_everyone=True,
    add_reactions=True,
    use_external_emojis=True,
    manage_messages=True,
    manage_roles=True,
    manage_webhooks=True,
    manage_channels=True,
    create_public_threads=True,
)


class ShannyBot(commands.Bot):
    def __init__(self, cfg: dict, env: dict):
        bot_cfg = cfg.get("bot", {})
        intents = discord.Intents.default()
        # Участники нужны для приветствий и счётчика (включается в Developer Portal)
        intents.members = bool(cfg.get("welcome", {}).get("enabled") or cfg.get("stats", {}).get("enabled"))
        activity = None
        if bot_cfg.get("status_text"):
            activity = discord.Activity(type=discord.ActivityType.watching, name=bot_cfg["status_text"])
        super().__init__(
            command_prefix=commands.when_mentioned,
            intents=intents,
            help_command=None,
            activity=activity,
            proxy=env.get("PROXY") or None,
        )
        self.cfg = cfg
        self.env = env
        self.db = DB(str(ROOT / "data" / "bot.db"))
        self.notifier = Notifier(self)
        self.color = parse_color(bot_cfg.get("embed_color"))
        self.http_session: aiohttp.ClientSession | None = None

    async def setup_hook(self) -> None:
        self.http_session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=25),
            headers={"User-Agent": USER_AGENT, "Accept-Language": "ru-RU,ru;q=0.9,en;q=0.8"},
            trust_env=True,  # подхватит PROXY из .env
        )
        for module, enabled in extensions(self.cfg):
            if enabled:
                await self.load_extension(module)
                log.info("Модуль загружен: %s", module)

        self.tree.on_error = self.on_app_command_error

        guild_id = self.cfg.get("bot", {}).get("guild_id", 0)
        if is_set(guild_id):
            guild = discord.Object(id=int(guild_id))
            self.tree.copy_global_to(guild=guild)
            synced = await self.tree.sync(guild=guild)
            log.info("Слэш-команды синхронизированы на сервер (%d шт.)", len(synced))
        else:
            synced = await self.tree.sync()
            log.info("Слэш-команды синхронизированы глобально (%d шт., появятся в течение часа)", len(synced))

    async def on_ready(self) -> None:
        log.info("✅ Бот онлайн: %s (ID %s)", self.user, self.user.id)
        invite = discord.utils.oauth_url(
            self.user.id, permissions=BOT_PERMISSIONS, scopes=("bot", "applications.commands")
        )
        log.info("Ссылка-приглашение: %s", invite)
        if not self.guilds:
            log.warning("Бот ещё не на сервере — открой ссылку выше и добавь его.")

    async def log_event(self, text: str) -> None:
        """Пишет в лог-канал, если он задан в конфиге."""
        channel_id = self.cfg.get("bot", {}).get("log_channel_id", 0)
        if not is_set(channel_id):
            return
        try:
            channel = self.get_channel(int(channel_id)) or await self.fetch_channel(int(channel_id))
            await channel.send(text[:2000], allowed_mentions=discord.AllowedMentions.none())
        except discord.HTTPException as e:
            log.warning("Не смог написать в лог-канал: %s", e)

    async def on_app_command_error(self, interaction: discord.Interaction, error: app_commands.AppCommandError):
        original = getattr(error, "original", error)
        if isinstance(error, app_commands.MissingPermissions):
            msg = "У тебя нет прав на эту команду, бро."
        elif isinstance(error, app_commands.BotMissingPermissions):
            msg = "Боту не хватает прав: " + ", ".join(error.missing_permissions)
        elif isinstance(error, app_commands.CommandOnCooldown):
            msg = f"Погоди ещё {error.retry_after:.0f} сек."
        elif isinstance(error, app_commands.CheckFailure):
            msg = "Эту команду тут юзать нельзя."
        elif isinstance(original, discord.Forbidden):
            msg = "Дискорд не пустил: боту не хватает прав, или его роль ниже нужной роли."
        else:
            log.error("Ошибка в команде /%s", getattr(interaction.command, "qualified_name", "?"), exc_info=original)
            msg = f"Что-то сломалось: `{type(original).__name__}: {original}`"
        try:
            if interaction.response.is_done():
                await interaction.followup.send(msg, ephemeral=True)
            else:
                await interaction.response.send_message(msg, ephemeral=True)
        except discord.HTTPException:
            pass

    async def close(self) -> None:
        await super().close()
        if self.http_session and not self.http_session.closed:
            await self.http_session.close()
        self.db.close()


async def runner(bot: ShannyBot, token: str) -> None:
    async with bot:
        await bot.start(token)


def main() -> None:
    setup_logging()
    load_dotenv(ROOT / ".env")
    cfg = load_config()

    token = (os.getenv("DISCORD_TOKEN") or "").strip()
    if not token or " " in token:
        fatal("❌ В .env не указан DISCORD_TOKEN. Скопируй .env.example в .env и вставь токен.")

    env = {k: (os.getenv(k) or "").strip() for k in ("TWITCH_CLIENT_ID", "TWITCH_CLIENT_SECRET", "YOUTUBE_API_KEY", "PROXY")}
    if env["PROXY"]:
        os.environ.setdefault("HTTPS_PROXY", env["PROXY"])
        os.environ.setdefault("HTTP_PROXY", env["PROXY"])
        log.info("Работаю через прокси")

    bot = ShannyBot(cfg, env)
    try:
        asyncio.run(runner(bot, token))
    except discord.PrivilegedIntentsRequired:
        fatal(
            "❌ Включи 'SERVER MEMBERS INTENT' в Discord Developer Portal → твоё приложение → Bot → "
            "Privileged Gateway Intents. Либо выключи [welcome] и [stats] в config.toml."
        )
    except discord.LoginFailure:
        fatal("❌ Discord не принял токен. Сбрось токен в Developer Portal и вставь новый в .env")
    except KeyboardInterrupt:
        log.info("Выключаюсь…")


if __name__ == "__main__":
    main()

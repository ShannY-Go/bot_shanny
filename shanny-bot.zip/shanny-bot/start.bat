@echo off
cd /d "%~dp0"
set PYTHONIOENCODING=utf-8
set PYTHONUTF8=1
title ShannY Bot

if not exist venv\Scripts\python.exe (
    echo [!] Run install.bat first.
    pause
    exit /b 1
)

:loop
venv\Scripts\python.exe bot.py
if errorlevel 2 (
    echo.
    echo [!] Settings error - see the message above. Fix it and run start.bat again.
    pause
    exit /b 2
)
echo.
echo Bot stopped. Restarting in 10 seconds... (close this window to stop)
timeout /t 10
goto loop

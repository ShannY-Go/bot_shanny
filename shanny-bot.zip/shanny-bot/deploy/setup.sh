#!/usr/bin/env bash
# Ставит ShannY Bot как службу: сам запускается при старте сервера и перезапускается при сбоях.
# Работает на Debian 12 / Ubuntu 24.04. Запуск:  bash deploy/setup.sh
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUN_USER="$(id -un)"
SERVICE=shanny-bot

echo "=== 1/4 Ставлю Python и нужные пакеты..."
sudo apt-get update -y
sudo apt-get install -y python3 python3-venv python3-pip unzip

if ! python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)'; then
  echo "[!] Нужен Python 3.11 или новее, а тут $(python3 --version 2>&1)."
  echo "    Создай сервер на Debian 12 или Ubuntu 24.04 — там подходящая версия."
  exit 1
fi

echo "=== 2/4 Создаю окружение и ставлю библиотеки..."
# venv, который приехал с Windows, на Linux не работает — выкидываем
[ -d "$DIR/venv/Scripts" ] && rm -rf "$DIR/venv"
python3 -m venv "$DIR/venv"
"$DIR/venv/bin/pip" install --quiet --upgrade pip
"$DIR/venv/bin/pip" install --quiet -r "$DIR/requirements.txt"

echo "=== 3/4 Проверяю файл с ключами (.env)..."
if [ ! -f "$DIR/.env" ]; then
  cp "$DIR/.env.example" "$DIR/.env"
fi
chmod 600 "$DIR/.env"
if ! grep -Eq '^DISCORD_TOKEN=.+' "$DIR/.env"; then
  echo
  echo "[!] В .env ещё нет токена бота."
  echo "    1) Выполни:  nano $DIR/.env"
  echo "    2) Впиши DISCORD_TOKEN=... (и YOUTUBE_API_KEY=...), сохрани: Ctrl+O, Enter, Ctrl+X"
  echo "    3) Запусти этот скрипт ещё раз:  bash deploy/setup.sh"
  exit 0
fi

echo "=== 4/4 Регистрирую службу и запускаю бота..."
sudo tee /etc/systemd/system/${SERVICE}.service >/dev/null <<UNIT
[Unit]
Description=ShannY Discord Bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${RUN_USER}
WorkingDirectory=${DIR}
ExecStart=${DIR}/venv/bin/python bot.py
Environment=PYTHONUNBUFFERED=1
Environment=PYTHONUTF8=1
Restart=always
RestartSec=10
# Код 2 = ошибка в настройках (кривой токен/конфиг): перезапуск не поможет, не крутимся вхолостую
RestartPreventExitStatus=2

[Install]
WantedBy=multi-user.target
UNIT

sudo systemctl daemon-reload
sudo systemctl enable ${SERVICE}
sudo systemctl restart ${SERVICE}
sleep 6

echo
sudo systemctl --no-pager --lines=0 status ${SERVICE} || true
echo
echo "Готово! Бот запущен и будет работать сам."
echo "  Логи в реальном времени:  journalctl -u ${SERVICE} -f      (выйти: Ctrl+C)"
echo "  Перезапустить:            sudo systemctl restart ${SERVICE}"
echo "  Остановить:               sudo systemctl stop ${SERVICE}"
